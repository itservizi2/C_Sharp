﻿using System.Collections.Generic;
using Telegram.Bot.Types.ReplyMarkups;

namespace YourAwesomeBot.Helpers
{
    public static class PaginationHelper
    {
        /// <summary>
        /// Creates an inline keyboard with 'Previous' and 'Next' buttons for pagination.
        /// </summary>
        /// <param name="currentPage">The current page number (1-based).</param>
        /// <param name="totalPages">The total number of available pages.</param>
        /// <param name="callbackPrefix">A unique string to identify the callback context (e.g., "books", "authors").</param>
        /// <returns>An InlineKeyboardMarkup object ready to be sent with a message.</returns>
        public static InlineKeyboardMarkup CreatePaginationKeyboard(int currentPage, int totalPages, string callbackPrefix)
        {
            var buttons = new List<InlineKeyboardButton>();

            // Only add a "Previous" button if not on the first page
            if (currentPage > 1)
            {
                buttons.Add(InlineKeyboardButton.WithCallbackData("⬅️ Previous", $"{callbackPrefix}_page_{currentPage - 1}"));
            }

            // Only add a "Next" button if not on the last page
            if (currentPage < totalPages)
            {
                buttons.Add(InlineKeyboardButton.WithCallbackData("Next ➡️", $"{callbackPrefix}_page_{currentPage + 1}"));
            }

            // The list of buttons is passed to the InlineKeyboardMarkup constructor.
            // Telegram will arrange these buttons in a row.
            return new InlineKeyboardMarkup(buttons);
        }
    }
}