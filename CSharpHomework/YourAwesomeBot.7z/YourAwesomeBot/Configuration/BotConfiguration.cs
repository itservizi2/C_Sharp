﻿namespace YourAwesomeBot.Configuration
{
    public class BotConfiguration
    {
        public string BotToken { get; set; }
        public string LibraryApiUrl { get; set; }
        public string OpenAiApiKey { get; set; }
    }
}